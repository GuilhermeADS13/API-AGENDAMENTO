package com.example.agendamento_unicap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendamentoUnicapApplicationTests {

	@Test
	void contextLoads() {
	}

}
