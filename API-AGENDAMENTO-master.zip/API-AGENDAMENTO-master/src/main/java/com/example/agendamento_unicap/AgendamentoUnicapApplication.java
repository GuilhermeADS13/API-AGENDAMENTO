package com.example.agendamento_unicap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgendamentoUnicapApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgendamentoUnicapApplication.class, args);
	}

}
